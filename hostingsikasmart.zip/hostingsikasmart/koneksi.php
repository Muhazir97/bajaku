<?php
  $host ="localhost"; //host server
  $user ="root"; //user login phpMyAdmin
  $pass ="Ip6f8viJXq20Nwcg"; //pass login phpMyAdmin
  $db ="kasir2"; //nama database
  $koneksi = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi gagal");
?>