<?php
  $host ="localhost"; //host server
  $user ="id13140173_bajaku"; //user login phpMyAdmin
  $pass ="MG>@~4njcAT(E]D)"; //pass login phpMyAdmin
  $db ="id13140173_kasir2"; //nama database
  $koneksi = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi gagal");
?>